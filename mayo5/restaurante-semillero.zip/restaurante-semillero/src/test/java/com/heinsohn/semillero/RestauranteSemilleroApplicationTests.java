package com.heinsohn.semillero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestauranteSemilleroApplicationTests {

	@Test
	void contextLoads() {
	}

}
